import React from "react";
import PaymentInfoSection from "./PaymentInfoSection";

function page() {
  return (
    <>
      

      <PaymentInfoSection />
    </>
  );
}

export default page;
