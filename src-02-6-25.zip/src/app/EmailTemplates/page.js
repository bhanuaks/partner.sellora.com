
import React from 'react'
import SellerLoginEmail from './SellerInvitation'
import SellerInvitation from './SellerInvitation'

function page() {
  return (
    <SellerInvitation />
  )
}

export default page