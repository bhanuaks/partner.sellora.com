

export const fileBasePath = process.env.NEXT_PUBLIC_FILE_PATH || 'https://seller.aksmedia.in/';
export const sellerUrl = process.env.SELLER_URL || 'https://seller.aksmedia.in/';