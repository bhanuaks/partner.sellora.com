import React from 'react'

function KeyFeaturesSection() {
  return (
    <div>KeyFeaturesSection</div>
  )
}

export default KeyFeaturesSection