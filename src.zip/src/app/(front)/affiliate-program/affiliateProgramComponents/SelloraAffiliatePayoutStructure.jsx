import React from 'react'

function SelloraAffiliatePayoutStructure() {
  return (
    <div>SelloraAffiliatePayoutStructure</div>
  )
}

export default SelloraAffiliatePayoutStructure