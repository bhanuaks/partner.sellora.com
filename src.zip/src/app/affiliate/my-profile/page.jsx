import React from 'react'
import MyProfileFromSection from './MyProfileFromSection'

function page() {
  return (
    <> 
<MyProfileFromSection />
    </>
  )
}

export default page